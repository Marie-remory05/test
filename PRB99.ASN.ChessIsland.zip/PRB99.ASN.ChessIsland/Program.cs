﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static char[,] board;
    static int boardHeight, boardWidth;
    static string player1, player2;
    static string currentPlayer;
    static List<(char Piece, int Row, int Col)> player1Pieces = new List<(char, int, int)>();
    static List<(char Piece, int Row, int Col)> player2Pieces = new List<(char, int, int)>();
    static int player1Flags = 0; // Count of player 1 flags
    static int player2Flags = 0; // Count of player 2 flags
    static void Main(string[] args)
    {
        StartGame();
    }



    static void StartGame()
    {
        // Player names input
        Console.WriteLine("Enter Player 1 name:");
        player1 = Console.ReadLine();
        Console.WriteLine("Enter Player 2 name:");
        player2 = Console.ReadLine();

        // Display available .map files
        string[] mapFiles = Directory.GetFiles(Directory.GetCurrentDirectory(), "*.map");
        if (mapFiles.Length == 0)
        {
            Console.WriteLine("No .map files found in the application folder.");
            return;
        }

        Console.WriteLine("Choose a map:");
        for (int i = 0; i < mapFiles.Length; i++)
        {
            Console.WriteLine($"{i + 1}: {Path.GetFileName(mapFiles[i])}");
        }

        int mapChoice;
        while (!int.TryParse(Console.ReadLine(), out mapChoice) || mapChoice < 1 || mapChoice > mapFiles.Length)
        {
            Console.WriteLine("Invalid choice. Please choose a valid number.");
        }

        // Load the selected map
        LoadMap(mapFiles[mapChoice - 1]);


        // Start the game
        currentPlayer = player1;
        while (true) // Main game loop
        {
            DrawBoard();
            Console.WriteLine($"Current turn: {currentPlayer} | Flags - {player1}: {player1Flags} | {player2}: {player2Flags}");

            // Ask for player action (move or use special piece)
            if (!PlayerTurn()) // Ask for player actions
            {
                Console.WriteLine($"{currentPlayer} passed their turn.");
            }

            // Evaluate Win condition
            if (CheckWinCondition())
            {
                DisplayEndMessage();
                break;
            }

            // Switch players
            currentPlayer = currentPlayer == player1 ? player2 : player1;
        }


        static void LoadMap(string mapFile)
        {
            var lines = File.ReadAllLines(mapFile);
            boardHeight = lines.Length;
            boardWidth = lines[0].Length;

            // Check for max dimensions
            if (boardHeight > 15 || boardWidth > 30)
            {
                Console.WriteLine("The map size is too large. Maximum height 15 and width 30.");
                return;
            }

            board = new char[boardHeight, boardWidth];

            // Load rocks and empty spaces
            for (int i = 0; i < boardHeight; i++)
            {
                var line = lines[i];
                for (int j = 0; j < boardWidth; j++)
                {
                    board[i, j] = line[j];
                }
            }

            // Place king and knight at random positions with special pieces
            PlacePieces();
        }
        static void PlacePieces()
        {
            PlacePiece('K', player1, player1Pieces); // King for player 1
            PlacePiece('P', player1, player1Pieces); // Knight for player 1
            PlacePiece('S', player1, player1Pieces); // Special piece for player 1

            PlacePiece('K', player2, player2Pieces); // King for player 2
            PlacePiece('P', player2, player2Pieces); // Knight for player 2
            PlacePiece('S', player2, player2Pieces); // Special piece for player 2
        }

        static void PlacePiece(char piece, string player, List<(char, int, int)> piecesList)
        {
            Random random = new Random();
            while (true)
            {
                int row = random.Next(boardHeight);
                int col = random.Next(boardWidth);
                if (board[row, col] == '.') // Check for empty cell
                {
                    board[row, col] = piece; // Place piece
                    piecesList.Add((piece, row, col)); // Add piece to the list
                    break;
                }
            }
        }

        static void DrawBoard()
        {
            Console.Clear();
            Console.Write("  ");
            for (int j = 0; j < boardWidth; j++)
            {
                Console.Write($"{(char)('A' + j)} ");
            }
            Console.WriteLine();

            for (int i = 0; i < boardHeight; i++)
            {
                Console.Write($"{i + 1} "); // Display row numbers
                for (int j = 0; j < boardWidth; j++)
                {
                    Console.Write($"{board[i, j]} ");
                }
                Console.WriteLine();
            }
        }


        static (int Row, int Col) ParseInput(string input)
        {
            if (input.Length < 2) return (-1, -1); // Invalid input length

            // Extract row and column characters
            char rowChar = input[0];
            char colChar = input[1];

            // Parse row (it's zero-based, so subtract 1)
            int row = int.Parse(rowChar.ToString()) - 1;

            // Parse column (assumed to be between A and O)
            int col = colChar - 'A'; // Convert character to zero-based column index

            // Ensure row and column are within acceptable bounds
            if (row < 0 || row >= boardHeight || col < 0 || col >= boardWidth) // Adjust depending on your board
            {
                return (-1, -1); // Invalid move
            }

            return (row, col);
        }


        static bool PlayerTurn()
        {
            char selectedPiece = GetPieceSelection();
            if (selectedPiece == '\0') return false; // No valid piece selected

            if (selectedPiece == 'S') // Use special piece if selected
            {
                UseSpecialPiece();
                return true;
            }

            // Get the current position of the selected piece
            (int Row, int Col) piecePosition = GetCurrentPiecePosition(selectedPiece);
            if (piecePosition == (-1, -1))
            {
                Console.WriteLine("Selected piece not found.");
                return false; // Exit the turn
            }

            List<(int Row, int Col)> possibleMoves = GetPossibleMoves(selectedPiece, piecePosition);
            if (possibleMoves.Count == 0)
            {
                Console.WriteLine("No possible moves. Turn passed.");
                return true; // No move made; player passes
            }

            // Confirm selection
            Console.WriteLine($"You selected {selectedPiece}. Would you like to proceed to move it? (Y/N)");
            string confirmation = Console.ReadLine()?.ToUpper();
            if (confirmation != "Y")
            {
                Console.WriteLine("Selection canceled. Please choose another piece.");
                return PlayerTurn(); // Restart the turn to allow re-selection
            }

            int selectedMoveIndex = GetMoveSelection(possibleMoves);
            MovePiece(selectedPiece, possibleMoves[selectedMoveIndex]);

            return true; // Successful turn
        }

        static void UseSpecialPiece()
        {
            Console.WriteLine("Using Special Piece (S) gives you an extra move or the ability to exchange places with an opponent's piece. Choose an option:");
            Console.WriteLine("1: Move an additional piece.");
            Console.WriteLine("2: Exchange pieces with the opponent.");

            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 2)
            {
                Console.WriteLine("Invalid choice. Please choose 1 or 2.");
            }

            if (choice == 1)
            { 
                Console.WriteLine("Select an additional piece to move:");
                char additionalPiece = GetPieceSelection();
                (int Row, int Col) position = GetCurrentPiecePosition(additionalPiece);
                List<(int Row, int Col)> possibleMoves = GetPossibleMoves(additionalPiece, position);
                if (possibleMoves.Count > 0)
                {
                    int selectedMoveIndex = GetMoveSelection(possibleMoves);
                    MovePiece(additionalPiece, possibleMoves[selectedMoveIndex]);
                }
                else
                {
                    Console.WriteLine("No possible moves for the additional piece. Turn ends.");
                }
            }
            else if (choice == 2)
            {
                Console.WriteLine("Choose a location to exchange with:");
                // Implement logic for players to exchange pieces at a specified board position
            }
        }
        static char GetPieceSelection()
        {
            Console.WriteLine($"Select a piece to move (K for King, P for Knight, or type 'C' to cancel selection):");

            Console.WriteLine($"Available pieces for {currentPlayer}:");
            var piecesList = currentPlayer == player1 ? player1Pieces : player2Pieces;
            foreach (var piece in piecesList)
            {
                Console.WriteLine($"{piece.Piece} at {ConvertToCoordinate((piece.Row, piece.Col))}"); // Display positions using ConvertToCoordinate
            }

            Console.WriteLine("Type 'C' to cancel your choice and reselect.");

            char moveChoice;
            while (true)
            {
                string input = Console.ReadLine().ToUpper();
                if (input.Length == 1 && (input[0] == 'K' || input[0] == 'P' || input[0] == 'C'))
                {
                    moveChoice = input[0];
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice. Choose either 'K' for King, 'P' for Knight or 'C' to cancel.");
                }
            }

            return moveChoice;
        }

        static (int Row, int Col) GetCurrentPiecePosition(char selectedPiece)
        {
            var piecesList = currentPlayer == player1 ? player1Pieces : player2Pieces;
            var pieceInfo = piecesList.Find(p => p.Piece == selectedPiece);
            return pieceInfo == default ? (-1, -1) : (pieceInfo.Row, pieceInfo.Col);
        }

        static List<(int Row, int Col)> GetPossibleMoves(char selectedPiece, (int Row, int Col) piecePosition)
        {
            List<(int Row, int Col)> moves = new List<(int Row, int Col)>();

            if (selectedPiece == 'K')
            {
                moves = GetPossibleMovesForKing(piecePosition);
            }
            else if (selectedPiece == 'P')
            {
                moves = GetPossibleMovesForKnight(piecePosition);
            }

            return moves;
        }

        static List<(int Row, int Col)> GetPossibleMovesForKing((int Row, int Col) currentPosition)
        {
            List<(int Row, int Col)> possibleMoves = new List<(int Row, int Col)>();

            var kingMoves = new (int RowOffset, int ColOffset)[]
            {
            (1, 0),  // Down
            (-1, 0), // Up
            (0, 1),  // Right
            (0, -1), // Left
            (1, 1),  // Down Right
            (1, -1), // Down Left
            (-1, 1), // Up Right
            (-1, -1) // Up Left
            };

            foreach (var move in kingMoves)
            {
                var newPosition = (Row: currentPosition.Row + move.RowOffset, Col: currentPosition.Col + move.ColOffset);

                if (IsValidMove(newPosition.Row, newPosition.Col))
                {
                    possibleMoves.Add(newPosition);
                }
            }

            return possibleMoves;
        }

        static List<(int Row, int Col)> GetPossibleMovesForKnight((int Row, int Col) currentPosition)
        {
            List<(int Row, int Col)> possibleMoves = new List<(int Row, int Col)>();

            var knightMoves = new (int RowOffset, int ColOffset)[]
            {
            (2, 1),  // Two steps forward and one to the right
            (2, -1), // Two steps forward and one to the left
            (-2, 1), // Two steps backward and one to the right
            (-2, -1),// Two steps backward and one to the left
            (1, 2),  // One step forward and two to the right
            (1, -2), // One step forward and two to the left
            (-1, 2), // One step backward and two to the right
            (-1, -2) // One step backward and two to the left
            };

            foreach (var move in knightMoves)
            {
                var newPosition = (Row: currentPosition.Row + move.RowOffset, Col: currentPosition.Col + move.ColOffset);

                if (IsValidMove(newPosition.Row, newPosition.Col))
                {
                    possibleMoves.Add(newPosition);
                }
            }

            return possibleMoves;
        }

        static string ConvertToCoordinate((int Row, int Col) position)
        {
            // Convert the row index (0-based) to a 1-based number
            int rowNumber = position.Row + 1; // Convert to 1-based row
                                              // Convert the column index (0-based) to a letter
            char columnLetter = (char)('A' + position.Col); // Convert column to A, B, C...

            return $"{columnLetter}{rowNumber}";
        }

        static void MovePiece(char piece, (int Row, int Col) newPosition)
        {
            var piecesList = currentPlayer == player1 ? player1Pieces : player2Pieces;
            var pieceInfo = piecesList.Find(p => p.Piece == piece);

            // Move the piece and place a flag at the new position
            if (currentPlayer == player1)
            {
                board[newPosition.Row, newPosition.Col] = 'O'; // Place player 1's flag at the new position
            }
            else
            {
                board[newPosition.Row, newPosition.Col] = 'O'; // Place player 2's flag at the new position
            }

            board[pieceInfo.Row, pieceInfo.Col] = 'O'; // Clear old position

            // Update the piece position
            piecesList.Remove(pieceInfo);
            piecesList.Add((piece, newPosition.Row, newPosition.Col)); // Update the position

            // Update flags count for the current player
            if (currentPlayer == player1)
            {
                player1Flags++;
            }
            else
            {
                player2Flags++;
            }
        }

        static int GetMoveSelection(List<(int Row, int Col)> possibleMoves)
        {
            // Display the available moves with their corresponding indices
            Console.WriteLine("Available moves:");
            for (int i = 0; i < possibleMoves.Count; i++)
            {
                Console.WriteLine($"{i}: Move to {ConvertToCoordinate(possibleMoves[i])}"); // Show in coordinate format
            }

            while (true)
            {
                Console.Write("Please select a move by entering the corresponding index: ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out int selectedIndex))
                {
                    if (selectedIndex >= 0 && selectedIndex < possibleMoves.Count)
                    {
                        return selectedIndex; // Return valid selection
                    }
                    else
                    {
                        Console.WriteLine("Invalid index. Please select a valid move from the list.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a numeric index.");
                }
            }
        }

        static bool IsValidMove(int row, int col)
        {
            // Return false if the cell contains a flag (either 'O' for player's flags or 'F' for opponent's flags)
            return row >= 0 && row < boardHeight && col >= 0 && col < boardWidth
                   && (board[row, col] == '.' || board[row, col] == 'O'); // Allow move to empty or opponent's flag locations
        }
        static bool CanPlay(List<(char Piece, int Row, int Col)> playerPieces)
        {
            foreach (var piece in playerPieces)
            {
                // Get all possible moves for the current piece
                List<(int Row, int Col)> possibleMoves = GetPossibleMoves(piece.Piece, (piece.Row, piece.Col));

                // If any piece has possible moves, the player can continue playing
                if (possibleMoves.Count > 0)
                {
                    return true;
                }
            }
            // No pieces have possible moves
            return false;
        }
        static bool CheckWinCondition()
        {
            // Logic to check if a player has won the game.
            // Define the winning conditions (e.g., eliminate all opponent's pieces).
            return false; // Placeholder code
        }

        static void DisplayEndMessage()
        {
            Console.Clear();
            if (!CanPlay(player1Pieces) && !CanPlay(player2Pieces))
            {
                Console.WriteLine("DRAW");
            }
            else if (!CanPlay(player1Pieces))
            {
                Console.WriteLine($"WINNER = {player2}");
            }
            else
            {
                Console.WriteLine($"WINNER = {player1}");
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}