﻿using System;


    public interface IGame
    {
         void StartGame();
         void MakeMove();
         bool CheckEndGame();
    }

