﻿using System;
using System.Collections.Generic;


    public class Player
    {
        public string Name { get; set; }
        public string Pieces { get; set; }
        public ConsoleColor ConsoleColor { get; set; }


        public void Display()
        {
        Console.WriteLine($"{Name} is aan de beurt");
    }
    }
