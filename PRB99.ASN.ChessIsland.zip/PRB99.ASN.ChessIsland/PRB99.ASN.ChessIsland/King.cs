﻿using System;
using System.Collections.Generic;


public class King : Piece
{
    public King() => Symbol = "K";

    public void Move()
    {
        Console.Write("Voer het vakje in waarin u de koning wilt verplaatsen (bv. A1): ");
        var input = Console.ReadLine().ToUpper();
        if (input.Length < 2) return;

        // Bepaal de doelpositie
        int targetX = input[0] - 'A'; // van A-Z naar 0-25 (max 30 kolommen)
        int targetY = int.Parse(input[1].ToString()) - 1; // van 1-15 naar 0-14

        // Check of de zet geldig is
        if (IsValidMove(targetX, targetY))
        {
            MovePiece(targetX, targetY);
            Console.WriteLine($"Koning verplaatst naar {input}.");
        }
        else
        {
            Console.WriteLine("Ongeldige zet! Probeer opnieuw.");
        }
    }

    private bool IsValidMove(int targetX, int targetY)
    {
        // Zorg ervoor dat de doelpositie binnen de grenzen ligt
        if (targetX < 0 || targetX >= 30 || targetY < 0 || targetY >= 15) return false;

        // Bereken het verschil van de huidige positie tot de doelpositie
        int deltaX = Math.Abs(Position.X - targetX);
        int deltaY = Math.Abs(Position.Y - targetY);

        // King's move: Mag met 1 stap in elke richting
        if ((deltaX <= 1 && deltaY <= 1) && !(deltaX == 0 && deltaY == 0))
        {
            return true;
        }

        return false;
    }
    private void MovePiece(int targetX, int targetY)
    {
        var targetCell = Position.Board.GetCells()[targetY, targetX];
        targetCell.Piece = this;
        Position.Piece = null;
        Position = targetCell;
    }


    public List<Move> ValidMoves()
    {
        // Logica om geldige zetten voor de koning te genereren
        return new List<Move>(); 
    }

    public void Display()
    {
        Console.ForegroundColor = ConsoleColor.Yellow; // Specifieke kleur voor de koning
        base.Display();
        Console.ResetColor();
    }
}

