﻿using System;
using System.Collections.Generic;


    public class Game 
    {
        public Board Board { get; set; }
        public List<Player> Players { get; set; }
        public Player CurrentTurn { get; set; }

        }


