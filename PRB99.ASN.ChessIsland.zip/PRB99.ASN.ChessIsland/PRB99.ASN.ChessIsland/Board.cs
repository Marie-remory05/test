﻿using System;
using static Cell;


public class Board
{
    public Cell[,] cells;
    public const int MaxHeight = 15;
    public const int MaxWidth = 30;
    public int height, width;
    public Board(string filePath)
    {
        cells = new Cell[height, width];
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                cells[y, x] = new Cell(this); // Pass the board reference to each cell
            }
        }
        Initialize(filePath);
    }
    public Cell[,] GetCells()
    {
        return cells;
    }

    public void Initialize(string filePath)
    {
        var lines = File.ReadAllLines(filePath);
        height = lines.Length;
        if (height > MaxHeight) throw new Exception("Maximum hoogte overschreden.");

        width = lines[0].Length;
        if (width > MaxWidth) throw new Exception("Maximum breedte overschreden.");

        cells = new Cell[height, width];

        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                // Instantiate a Cell by passing the current instance of Board
                cells[i, j] = new Cell(this) { X = j, Y = i, State = CellState.Empty };
                if (lines[i][j] == 'X')
                {
                    cells[i, j].State = CellState.Occupied;
                }
            }
        }
    }

    public void Display()
    {
        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                cells[i, j].Display();
            }
            Console.WriteLine();
        }
    }
}



