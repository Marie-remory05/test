﻿using System;
using System.Collections.Generic;


    public interface IMovable
    {
        void Move();
        List<Move> ValidMoves();
    }

