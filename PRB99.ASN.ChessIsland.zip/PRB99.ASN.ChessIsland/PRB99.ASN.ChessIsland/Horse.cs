﻿using System;
using System.Collections.Generic;


public class Horse : Piece
{
    public Horse() => Symbol = "P"; // Stuk Symbol voor het paard
    
    public void Move()
    {
        Console.Write("Voer het vakje in waarin u het paard wilt verplaatsen (bijv. A1): ");
        var input = Console.ReadLine().ToUpper();
        if (input.Length < 2) return;

        // Bepaal de doelpositie
        int targetX = input[0] - 'A'; // van A-Z naar 0-25
        int targetY = int.Parse(input[1].ToString()) - 1; // van 1-15 naar 0-14

        // Controleren of de zet geldig is
        if (IsValidMove(targetX, targetY))
        {
            MovePiece(targetX, targetY);
            Console.WriteLine($"Paard verplaatst naar {input}.");
        }
        else
        {
            Console.WriteLine("Ongeldige zet! Probeer opnieuw.");
        }
    }

    private bool IsValidMove(int targetX, int targetY)
    {
        // Zorg ervoor dat de doelpositie binnen de grenzen ligt
        if (targetX < 0 || targetX >= 30 || targetY < 0 || targetY >= 15) return false;

        // Paard kan in een "L"-vorm bewegen
        int deltaX = Math.Abs(Position.X - targetX);
        int deltaY = Math.Abs(Position.Y - targetY);

        // Valideert de "L" vorm beweging
        return (deltaX == 2 && deltaY == 1) || (deltaX == 1 && deltaY == 2);
    }

    private void MovePiece(int targetX, int targetY)
    {
        var targetCell = Position.Board.GetCells()[targetY, targetX]; 
        targetCell.Piece = this;
        Position.Piece = null;
        Position = targetCell;
    }
    public List<Move> ValidMoves()
    {
        // Logica om geldige zetten voor het paard te genereren
        return new List<Move>(); 
    }

    public void Display()
    {
        Console.ForegroundColor = ConsoleColor.Green; // Specifieke kleur voor het paard
        base.Display();
        Console.ResetColor();
    }
}
