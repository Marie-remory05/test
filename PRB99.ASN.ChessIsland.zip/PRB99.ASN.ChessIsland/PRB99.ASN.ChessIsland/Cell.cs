﻿using System;
using static Board;

public class Cell 
{
    public int X { get; set; }
    public int Y { get; set; }
    public CellState State { get; set; }
    public Piece Piece { get; set; }
    public Board Board { get; set; }

    public Cell(Board board)
    {
        this.Board = board; 
    }


    public void Display()
    {
        
        char displayChar = State switch
        {
            CellState.Occupied => 'X',
            CellState.Empty => '.',
            _ => ' '
        };
        Console.Write(displayChar + " ");
    }

    public enum CellState
    {
        Empty,
        Occupied,
        Flag
    }
}

