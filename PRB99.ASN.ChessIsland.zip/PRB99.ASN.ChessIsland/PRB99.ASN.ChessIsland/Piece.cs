﻿using System;
using System.Collections.Generic;


    public class Piece : IMovable, IDrawable
    {
        public Cell Position { get; set; }
        public string Symbol { get; set; }

    public void Move() 
    {
    
    }
    public List<Move> ValidMoves() 
    {
        return new List<Move>(); 
    }


        public void Display()
        {
        Console.Write(Symbol);
    }
    }
