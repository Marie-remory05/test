﻿using System;

public class Move
{
   
        public Piece Piece { get; set; }
        public Cell From { get; set; }
        public Cell To { get; set; }

        public void Execute()
        {
           To.Piece = Piece;
           From.Piece = null;
           Piece.Position = To;
        }

        public void Display()
        {
          Console.WriteLine($"Van {From.X},{From.Y} naar {To.X},{To.Y}");
        }
}

